import sys
import re


class SpellFixer:
    my_dict = dict()
    dictIsValid = False
    validWords = set()
    wordsIsValid = False

    # load my_dict and validWords from file
    def __init__(self, keyboard, words) -> None:
        # load file into dictionary
        try:
            with open(keyboard, "r") as file:
                for line in file:
                    letters = line.strip().split(" ")
                    self.my_dict[letters[0]] = letters[1:]
            self.dictIsValid = True
        except:
            print("Usage: python3 spellfixer.py {words-filename} {keyboard-filename}")

        # load the valid words into validWords
        try:
            with open("words.txt", "r") as file:
                for word in file:
                    self.validWords.add(word.strip().lower())
            self.wordsIsValid = True
        except:
            print("Usage: python3 spellfixer.py {words-filename} {keyboard-filename}")

    # gets the correctedWord
    def getCorrectedWord(self, word):
        # if word is in valid words return as it is
        if (word in self.validWords):
            return word
        else:
            # if word contains char not in the keyboard keys entered return it
            for char in word:
                if (char not in self.my_dict.keys()):
                    print("haha")
                    return word

        # generate words by replacing one char with adjacent keys
        newWord = self.generatePossibleWordsWithDict(word)
        if (newWord):
            return newWord

        # adds a repetition for letter
        newWord = self.addALetter(word)
        if (newWord):
            return newWord

        newWord = self.removeALetter(word)
        if (newWord):
            return newWord
        return word

    # removes a letter and checks if it is valid
    def removeALetter(self, word):
        for i in range(len(word)):
            newWord = word[:i] + word[i + 1:]
            if (newWord in self.validWords):
                return newWord
        return None

    # adds a repetition for letter and checks if it is valid
    def addALetter(self, word):
        for i in range(len(word)):
            newWord = word[:i] + word[i] + word[i:]
            if (newWord in self.validWords):
                return newWord
        return None

    # generate words by replacing one char with adjacent keys
    def generatePossibleWordsWithDict(self, word) -> str:
        for i in range(len(word)):
            for char in self.my_dict[word[i]]:
                newWord = word[:i] + char + word[i + 1:]
                if (newWord in self.validWords):
                    return newWord
        return None


"""""
Function to remove punctuation and whitespaces from the user input
"""
def fixed_user_input(input):
    input = re.sub(r'[^]\w\s][, . \? \!]?', ' ', user_input)  # punctuation removal
    input_list = input.split() # whitespace removal
    clean_user_input = []
    for word in input_list:
        clean_user_input.append(word.lower())

    return clean_user_input


keyboardFile = sys.argv[2]
wordfile=sys.argv[1]
SpellFixer = SpellFixer(keyboardFile, wordfile)
print("**********************  USER INPUT  **********************\n")
user_input = input("Enter your sentence:  ")
user_input_words= fixed_user_input(user_input)

print("\nCorrected Sentence:- ", end=" ")
for i in user_input_words:
    print(SpellFixer.getCorrectedWord(i), end=" ")


